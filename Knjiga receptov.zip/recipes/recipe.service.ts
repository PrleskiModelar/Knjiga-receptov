import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Recipe } from './recipe.model';
import { Ingredient } from '../shared/ingredient.model';
import { ShoppingListService } from '../shopping-list/shopping-list.service';

@Injectable()
export class RecipeService {
  recipesChanged = new Subject<Recipe[]>();
  private recipes: Recipe[] = [
    new Recipe(
           'Jabolčna rezina',
           'Super okusna babičina jabolčna rezina',
           'https://stefkinedobrote.si/wp-content/uploads/2018/11/jabolcna_rezina.jpg',
           [new Ingredient('Jajca', 3), new Ingredient('Sladkor', 1), new Ingredient('Moka', 1), new Ingredient('Pecilni prašek', 1), new Ingredient('Mleko', 1), new Ingredient('Jabolka', 6)]
         ),
     new Recipe(
       'Pizza',
       'Okusna pizza iz pekača',
       'https://pizzamarija.com/image/catalog/salyami1.png',
       [new Ingredient('Moka', 1), new Ingredient('Kvas', 1), new Ingredient('voda', 0.5), new Ingredient('Šunka', 1), new Ingredient('Sir', 1), new Ingredient('Salama', 0.3)]
     )
  ];

  constructor(private slService: ShoppingListService) {}

  setRecipes(recipes: Recipe[]) {
    this.recipes = recipes;
    this.recipesChanged.next(this.recipes.slice());
  }

  getRecipes() {
    return this.recipes.slice();
  }

  getRecipe(index: number) {
    return this.recipes[index];
  }

  addIngredientsToShoppingList(ingredients: Ingredient[]) {
    this.slService.addIngredients(ingredients);
  }

  addRecipe(recipe: Recipe) {
    this.recipes.push(recipe);
    this.recipesChanged.next(this.recipes.slice());
  }

  updateRecipe(index: number, newRecipe: Recipe) {
    this.recipes[index] = newRecipe;
    this.recipesChanged.next(this.recipes.slice());
  }

  deleteRecipe(index: number) {
    this.recipes.splice(index, 1);
    this.recipesChanged.next(this.recipes.slice());
  }
}
